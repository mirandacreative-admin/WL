<form method="get" action="http://lci-mt.iii.com/iii/encore/Home,$Search.form.sdirect" name="form" id="catform">
	<input class="clear hm" name="target" placeholder="Search Library Catalog.." id="target" size="22" type="text">
	<input type="submit" value="" class="submit">
</form>
