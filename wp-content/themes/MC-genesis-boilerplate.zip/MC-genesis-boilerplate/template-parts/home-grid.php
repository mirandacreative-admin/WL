<div class="row squaregrid padfix">
	<div class="col">
		<h2><a href="#">Hoopla</a></h2>
		<p>Instantly borrow digital movies, music, eBooks and more, 24/7 with your library card</p>
	</div>
	<div class="col">
		<h2><a href="#">Museum Passes</a></h2>
		<p>Choose as you go from 10 available museums, activities and tours. </p>
	</div>	
	<div class="col">
		<h2><a href="#">Room Reservations</a></h2>
		<p>Our academic libraries have rooms set aside for student study and collaboration.</p>		
	</div>	
	<div class="w-100"></div>
	<div class="col">
		<h2><a href="#">Overdrive</a></h2>
		<p>Borrow eBooks, audiobooks, and more from your local public library - anywhere, anytime. All you need is a library card.</p>
	</div>
	<div class="col">
		<h2><a href="#">Healthy Indulgences</a></h2>
		<p>Chocolate treats made from natural ingredients.  </p>
	</div>	
	<div class="col">
		<h2><a href="#">Technology Classes</a></h2>
		<p>Learn skills and technologies to advance your skill. Important for small and large businesses.</p>		
	</div>	
</div>