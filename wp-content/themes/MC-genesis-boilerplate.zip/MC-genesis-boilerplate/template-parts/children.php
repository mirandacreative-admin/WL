<div class="children-box" style="width: 100%; min-height: 888px;">
   <div class="row">
      <div class="col-sm-3">
         <div class="block">
            <div class="rel">
               <img src="<?php echo get_home_url(); ?>/wp-content/themes/MC-genesis-boilerplate/images/grownwl.svg">
               <h2 class="abs grnups">Grown Ups</h2>
            </div>
         </div>
         <div class="block">
            <div class="rel"><img class="margblock" src="<?php echo get_home_url(); ?>/wp-content/themes/MC-genesis-boilerplate/images/left-books.png"></div>
         </div>
         <div class="block">
            <div class="rel">
               <img class="easle" src="<?php echo get_home_url(); ?>/wp-content/themes/MC-genesis-boilerplate/images/programswl.svg">
               <h2 class="abs prgms">Programs</h2>
            </div>
         </div>
      </div>
      <div class="col-sm-6">
         <div class="block">
            <div class="rel">
            	<img src="<?php echo get_home_url(); ?>/wp-content/themes/MC-genesis-boilerplate/images/todays-message-bg.png">
	            <p class="abs todaymsg">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis dignissim leo ut nibh placerat, scelerisque convallis mi consequat. Sed maximus semper ex quis vehicula. Pellentesque a massa vitae ipsum sagittis suscipit.
            	</p>
            </div>
         </div>
         <div class="block">
            <div class="rel">
            	<img class="rug" src="<?php echo get_home_url(); ?>/wp-content/themes/MC-genesis-boilerplate/images/carpetwl.svg">
            	<p class="abs kidstablet">App/Website of the month</p>
            	<img class="abs girlone" src="<?php echo get_home_url(); ?>/wp-content/themes/MC-genesis-boilerplate/images/girl1wl.svg"> 
            	<img class="abs tabletgirl" src="<?php echo get_home_url(); ?>/wp-content/themes/MC-genesis-boilerplate/images/girltabletwl.svg">
            	<img class="abs tabletboy" src="<?php echo get_home_url(); ?>/wp-content/themes/MC-genesis-boilerplate/images/boywl.svg">            	            	           	
            </div>
         </div>
      </div>
      <div class="col-sm-3">
         <div class="block">
            <div class="rel">
           		<img class="games" src="<?php echo get_home_url(); ?>/wp-content/themes/MC-genesis-boilerplate/images/gameswl.svg">  
            </div>
         </div>
         <div class="block">
            <div class="rel">
           		<img class="thoubooks" src="<?php echo get_home_url(); ?>/wp-content/themes/MC-genesis-boilerplate/images/bookswl.svg">  
            </div>
         </div>
         <div class="block">  
            <div class="rel">
           		<img class="teddyshelf" src="<?php echo get_home_url(); ?>/wp-content/themes/MC-genesis-boilerplate/images/shelfwl.svg">  
           		<img class="abs teddy" src="<?php echo get_home_url(); ?>/wp-content/themes/MC-genesis-boilerplate/images/bearwl.svg">           		
            </div>
         </div>
         <div class="block">
            <div class="rel">
           		<img class="greatread" src="<?php echo get_home_url(); ?>/wp-content/themes/MC-genesis-boilerplate/images/readswl.svg">  
            </div>
         </div>
         <div class="block">
            <div class="rel">
           		<img class="abs toys" src="<?php echo get_home_url(); ?>/wp-content/themes/MC-genesis-boilerplate/images/toyswl.svg">  
            </div>
         </div>
      </div>
   </div>
</div>